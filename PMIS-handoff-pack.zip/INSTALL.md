# Install the PMIS Handoff Layer

Copy the pack contents into the PMIS repository root while preserving directories:

```text
PMIS repository/
├── AGENTS.md
└── .agent/
    ├── doc/
    │   ├── AGENT_PRODUCT_KNOWLEDGE.md
    │   ├── GANTT_DEPENDENCY_RENDERING.md
    │   ├── INITIAL_PMIS_HANDOFF.md
    │   ├── INITIAL_PROMPT_AGENT.md
    │   └── pict/
    └── handoff/
        ├── HANDOFF_PROTOCOL.md
        ├── DECISIONS.md
        └── CURRENT_STATE.md
```

The four existing documents remain unchanged. This pack adds an authority layer above them:

- `AGENT_PRODUCT_KNOWLEDGE.md` remains the product and domain source of truth.
- `GANTT_DEPENDENCY_RENDERING.md` remains authoritative for connector rendering.
- `INITIAL_PMIS_HANDOFF.md` becomes an implementation snapshot.
- `INITIAL_PROMPT_AGENT.md` becomes historical bootstrap context, not an active role prompt.

After copying, start Codex with:

> Read AGENTS.md and initialize .agent/handoff/CURRENT_STATE.md from the repository. Do not modify implementation or product decisions. Report any contradictions before changing files.

If the existing documents live somewhere other than `.agent/doc/`, either move them there or update only the paths in `AGENTS.md`.

